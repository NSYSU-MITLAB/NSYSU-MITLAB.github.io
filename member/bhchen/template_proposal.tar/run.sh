latex nsysu.tex
bibtex nsysu
latex nsysu.tex
latex nsysu.tex
dvipdfm nsysu.dvi 
